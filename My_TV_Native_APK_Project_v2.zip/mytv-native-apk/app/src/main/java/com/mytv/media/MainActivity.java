package com.mytv.media;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private String deviceId;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        if (deviceId == null || deviceId.isEmpty()) deviceId = UUID.randomUUID().toString();

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new FilmixBridge(), "AndroidFilmix");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private final class FilmixBridge {
        @JavascriptInterface public void search(final String q) {
            runApi("search?story=" + enc(q), "search");
        }

        @JavascriptInterface public void post(final String id) {
            runApi("post/" + enc(id), "post");
        }

        @JavascriptInterface public String deviceInfo() {
            try {
                JSONObject o = new JSONObject();
                o.put("id", deviceId);
                o.put("name", Build.MODEL == null ? "Android" : Build.MODEL);
                o.put("vendor", Build.MANUFACTURER == null ? "Android" : Build.MANUFACTURER);
                o.put("os", "Android " + Build.VERSION.RELEASE);
                o.put("apk", "mytv/1.0");
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }
    }

    private void runApi(final String path, final String kind) {
        executor.execute(() -> {
            String[] bases = new String[]{"https://filmixapp.cyou/api/v2", "http://filmixapp.cyou/api/v2"};
            Exception last = null;
            for (String base : bases) {
                try {
                    String url = base + "/" + path
                            + (path.contains("?") ? "&" : "?")
                            + "user_dev_id=" + enc(deviceId)
                            + "&user_dev_name=" + enc(Build.MODEL == null ? "Android" : Build.MODEL)
                            + "&user_dev_vendor=" + enc(Build.MANUFACTURER == null ? "Android" : Build.MANUFACTURER)
                            + "&user_dev_os=" + enc("Android " + Build.VERSION.RELEASE)
                            + "&user_dev_apk=" + enc("mytv/1.0");
                    String body = get(url);
                    postToJs(kind, body, null);
                    return;
                } catch (Exception e) { last = e; }
            }
            postToJs(kind, null, last == null ? "Нет ответа" : last.toString());
        });
    }

    private String get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(12000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Accept", "application/json, text/plain, */*");
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android; Мой TV) FilmixClient/2");
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
        String body = read(in);
        c.disconnect();
        if (code < 200 || code >= 400) throw new Exception("HTTP " + code + ": " + body);
        return body;
    }

    private String read(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder(); String line;
        while ((line = r.readLine()) != null) b.append(line);
        r.close(); return b.toString();
    }

    private void postToJs(final String kind, final String body, final String error) {
        runOnUiThread(() -> {
            String b = body == null ? "null" : JSONObject.quote(body);
            String e = error == null ? "null" : JSONObject.quote(error);
            web.evaluateJavascript("window.__filmixNativeResult(" + JSONObject.quote(kind) + "," + b + "," + e + ")", null);
        });
    }

    private static String enc(String s) {
        try { return URLEncoder.encode(s == null ? "" : s, "UTF-8"); }
        catch (Exception e) { return ""; }
    }
}
