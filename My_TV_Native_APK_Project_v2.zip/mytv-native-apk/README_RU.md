# Мой TV — Native APK bridge

Основа: `Мой TV — База 17`.

Что сделано:
- HTML-приложение сохранено как локальный asset;
- Android WebView сохраняет текущий интерфейс и локальные видео;
- добавлен нативный Java-мост `AndroidFilmix`;
- запросы Filmix v2 выполняются из Android-кода, а не из браузерного fetch;
- используются обязательные параметры устройства Filmix v2;
- найденная MP4-ссылка передаётся обратно в HTML-плеер;
- добавлен запасной HTTP/HTTPS API host;
- INTERNET + cleartext включены.

## Сборка

Проект рассчитан на стандартный Android Gradle Plugin 8.7.3 / compileSdk 35.
В этой среде Android SDK/Gradle отсутствуют, поэтому сам бинарный APK здесь не был скомпилирован.

Для облачной сборки нужен сервис, принимающий Android Gradle project ZIP, либо любой Android CI.
